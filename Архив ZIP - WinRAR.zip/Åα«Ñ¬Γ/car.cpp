#include "car.h"
#include <QDebug>
#include <QPixmap>
#include <QPainter>
#include "mapx.h"
#include "bd.h"

#include <QDebug>
QPixmap * car::add_im(QPixmap *im1,QPixmap *im2){
    QPixmap * ret = new QPixmap(im1->size());
    QPainter p(ret);
    p.drawPixmap(0,0,*im1);
    p.drawPixmap(0,0,*im2);

    return ret;
}
void car::del(){
    start = 0;
    x = -100;
    y = -100;
    nMar = 1;
    lMar = 0;
    draw();

}
car::car(QLabel *Labx,mapx * m,long long int * t)
{

    start = 0;
    map = m;
    BD = new bd;
    tik = t;
    Lab = Labx;
    type = 1;
    x = 0;
    y = 0;
    QPixmap i1,i2,i3;

        IM1.load(":/new/prefix1/Resources/BCvertical.png");

        IM2.load(":/new/prefix1/Resources/Trailer.png");
        IM3.load(":/new/prefix1/Resources/Truck.png");


    nMar = 1;
    lMar = 0;

    end = 1;
}

int car::mod(int x){
    if(x==0)return x;
    if(x<0){

        return x/(x*-1);

    }else{

        return   x/x;

    }
}

void  car::rotate(QPixmap *im1){
    QSize size = im1->size();
    int x = im1->width();
    int y = im1->height();

    QPixmap r(size*2);
    r.fill(QColor(0,0,0,0));
    QPainter p(&r);
    p.translate(r.size().width()/2,r.size().height()/2);
    p.rotate(90);
    p.translate(-r.size().width()/2,-r.size().height()/2);

    p.drawPixmap(x,y,*im1);
    p.end();

    *im1 = r.copy(0,2*y-x,y,x);

}

QPixmap *   car::rotate2(QPixmap *im,int ug){
    QPixmap * im1 = new  QPixmap;
    *im1 = *im;
    if(ug == 0) {
        rotate(im1);

    }

    if(ug == 90) {


    }

    if(ug == 180) {
        rotate(im1);
        rotate(im1);
        rotate(im1);

    }

    if(ug == 270) {

        rotate(im1);
        rotate(im1);
    }
    return im1;
}

void car::draw(){

    Lab->setGeometry(x-40,y-40,50,50);
    if(type == 1) Lab->setPixmap(rotate2(&IM1,ug)->scaled(50,50));
    if(type == 2) Lab->setPixmap(rotate2(&IM2,ug)->scaled(50,50));
    if(type == 3) Lab->setPixmap(rotate2(&IM3,ug)->scaled(50,50));

}

void car::W(){
   // qDebug(std::to_string(x).c_str());
   // qDebug(std::to_string(y).c_str());
   // qDebug(std::to_string(Mar[nMar][0]*50).c_str());
   // qDebug(std::to_string(Mar[nMar][1]*50).c_str());
    //qDebug(" ");

    if(start == 0) start = *tik;

     map->Cmap[(((x)/50)-1)*20+(((y)/50)-1)] = 0;

    if(x== Mar[nMar][0]*50 &&y== Mar[nMar][1]*50){
        nMar++;
        if(nMar==lMar)end = 1;

    }

    if(map->Smap[((x/50-1)*20)+(y/50-1)]>-1){
        if(svID!=((x/50-1)*20)+(y/50-1)){
          //  qDebug(std::to_string(((x/50-1)*20)+(y/50-1)).c_str());
            map->Smap[((x/50-1)*20)+(y/50-1)]++;
           //  qDebug(std::to_string(map->Smap[((x/50-1)*20)+(y/50-1)]).c_str());
            float ti = (float(*tik) / 20.0) / 60.0;
           //  qDebug(std::to_string(map->Smap[((x/50-1)*20)+(y/50-1)]/ ti).c_str());
            svID =((x/50-1)*20)+(y/50-1);
            float mx[4] = {
                 float(((x/50-1)*20)+(y/50-1)),
                 float(map->Smap[((x/50-1)*20)+(y/50-1)]),
                 map->Smap[((x/50-1)*20)+(y/50-1)]/ ti,
                 0

            };
            BD->set_Lite(mx);

        }
    }
    if(!end){

        int z = 5;
        int w,h;
        int w2,h2;
        w2 = ((x)/50)-1;
        h2 = ((y)/50)-1;

        if(mod(Mar[nMar][0]-Mar[nMar-1][0]) == 1 ) ug = 0;
        if(mod(Mar[nMar][0]-Mar[nMar-1][0]) == -1 ) ug = 180;
        if(mod(Mar[nMar][1]-Mar[nMar-1][1]) == 1 ) ug = 270;
        if(mod(Mar[nMar][1]-Mar[nMar-1][1]) == -1 ) ug = 90;

        if(ug == 0) {
           w =  (x)/50;
           h =  (y-50)/50;
           w2++;
        }
        if(ug == 90) {
            w =  (x-50)/50;
            h =  (y-50)/50;
            h2;
         }
        if(ug == 180) {
            w =  (x-50)/50;
            h =  (y-50)/50;
            w2;
         }
        if(ug == 270) {
            w =  (x-50)/50;
            h =  (y)/50;
            h2++;
         }

        /*
    if(x ==1) return &LD;
    if(x ==2) return &RD;
    if(x ==3) return &UD;
    if(x ==4) return &DD;
    if(x ==5) return &PD;
    if(x ==6) return &WD;
    if(x ==7) return &DZ;
    if(x ==8) return &GZ;
    if(x ==9) return &PZ;
    if(x ==10) return &ZH;
    if(x ==11) return &ZV;
    if(x ==12) return &PE;
    if(x ==13) return &SVg;*/

        if(h>0&&w>0&&w<20&&h<20){
            int r = map->Omap[w*20+h];
            if(r == 7 ||(r == 8&&type ==2)||(r == 9&&type ==3)) z = 0;
            if(map->Omap[w*20+h] == 1) z = 0;
        }

        if(map->Cmap[w2*20+h2]==1){
            z = 0;
        }
        if(map->Stmap[w2*20+h2]==0){
            z = 0;
        }

        if(ug == 0) x+=z;
        if(ug == 90) y-=z;
        if(ug == 180) x-=z;
        if(ug == 270) y+=z;
     map->Cmap[(((x)/50)-1)*20+(((y)/50)-1)] = 1;



    }else{

        int mx[3] = {

            carID,
            start,
            int(*tik)-start

        };

        BD->set_Car(mx);

        if(map->carsZ>100){
            map->nZ++;
            int mx[2] = {

                map->nZ,
                int(*tik/20)


            };
            BD->set_LR(mx);
            *trx = 0;
            *tik = 1;
        }

        if(*trx == 1 ||map->carsZ>100 ){
            del();
        }
        if(*trx == 2  ){
           map->carsZ++;
           x = Mar[0][0]*50;
           y = Mar[0][1]*50;
           nMar = 1;
           end = 0;
        }

    }
    if(*trx == 0  ){
        *tik = 1;

        del();
    }

}
