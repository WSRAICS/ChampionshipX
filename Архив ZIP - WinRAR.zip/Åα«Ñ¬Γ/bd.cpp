#include "bd.h"
#include "iostream"
#include <QDebug>

#include "sqlite3.h"
using namespace std;
bd::bd()
{
FileName = "data.db";
}

void bd::criate(char * table,int n,char ** val,char ** tipe){

    string SQL;
    SQL.append("CREATE TABLE ");
    SQL.append(table);
    SQL.append(" ( ");
    for(int i =0;i<n;i++){

        if(i)SQL.append(" , ");
        SQL.append(val[i]);
        SQL.append(" ");
        SQL.append(tipe[i]);

    }
    SQL.append(" ); ");

    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

    //if(ch != SQLITE_OK) qDebag(err);
   //sqlite3_close(db);

}
void bd::criateL(){

    string SQL;
    SQL.append(" CREATE TABLE Traffic_light ( Id_light	INTEGER, Car_count_full_run	INTEGER , Car_average_in_minute	INTEGER, Count_color_switches	INTEGER);");



    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

    //if(ch != SQLITE_OK) qDebag(err);
  // sqlite3_close(db);

}

void bd::criateLR(){

    string SQL;
    SQL.append(" CREATE TABLE Learning_Records ( Iteration_id	INTEGER, Iteration_time	INTEGER );");



    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

    //if(ch != SQLITE_OK) qDebag(err);
  // sqlite3_close(db);

}

void bd::criateC(){

    string SQL;
    SQL.append(" CREATE TABLE Cars_stats ( Car_id INTEGER, Car_spawn_ticks INTEGER, Car_exit_ticks	INTEGER);");




    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

    //if(ch != SQLITE_OK) qDebag(err);
  // sqlite3_close(db);

}

void bd::criate2(string SQL){



    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

    //if(ch != SQLITE_OK) qDebag(err);
  // sqlite3_close(db);

}


void bd::cr_tmap(const char * t){

    string SQL;
    SQL.append("CREATE TABLE ");
    SQL.append(t);
    SQL.append("( val int);");
    criate2(SQL);


}

void bd::drop(const char * table){

    string SQL;
    SQL.append("DROP TABLE ");
    SQL.append(table);


    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

   // if(ch != SQLITE_OK) qDebag(err);
  // sqlite3_close(db);

}

void bd::set(const char * table,int n1,int n2, int * map){
    sqlite3_open(FileName,&db);
    for(int i =0;i<n1;i++){
    string SQL;
    SQL.append("INSERT INTO  ");
    SQL.append(table);
    SQL.append(" VALUES ( ");
    for(int j =0;j<n2;j++){

        if(j)SQL.append(" , ");
        SQL.append(std::to_string( map[i*n2+j]));


    }
    SQL.append(" ); ");
   // qDebug(SQL.c_str());

    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

   if(ch != SQLITE_OK) qDebug(err);
   // sqlite3_close(db);
    }
}

void bd::set_Lite(float * map){

    qDebug("11");
    sqlite3_open(FileName,&db);

    string SQL;
    SQL.append("INSERT INTO  ");
    SQL.append("Traffic_light");
    SQL.append(" VALUES ( ");



    SQL.append(std::to_string( map[0]));
    SQL.append(" , ");
    SQL.append(std::to_string( map[1]));
    SQL.append(" , ");
    SQL.append(std::to_string( map[2]));
    SQL.append(" , ");
    SQL.append(std::to_string( map[3]));



    SQL.append(" ); ");
   // qDebug(SQL.c_str());

    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

   if(ch != SQLITE_OK) qDebug(err);
    sqlite3_close(db);

}

void bd::set_LR( int * map){

    //qDebug("11");
    sqlite3_open(FileName,&db);

    string SQL;
    SQL.append("INSERT INTO  ");
    SQL.append("Learning_Records");
    SQL.append(" VALUES ( ");



    SQL.append(std::to_string( map[0]));
    SQL.append(" , ");
    SQL.append(std::to_string( map[1]));




    SQL.append(" ); ");
   // qDebug(SQL.c_str());

    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

   if(ch != SQLITE_OK) qDebug(err);
    sqlite3_close(db);

}

void bd::set_Car(int * map){

    //qDebug(std::to_string(map[1]).c_str());
    sqlite3_open(FileName,&db);

    string SQL;
    SQL.append("INSERT INTO  ");
    SQL.append("Cars_stats");
    SQL.append(" VALUES ( ");



    SQL.append(std::to_string( map[0]));
    SQL.append(" , ");
    SQL.append(std::to_string( map[1]));
    SQL.append(" , ");
    SQL.append(std::to_string( map[2]));



    SQL.append(" ); ");
   // qDebug(SQL.c_str());

    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),0,0,&err);

   if(ch != SQLITE_OK) qDebug(err);
    sqlite3_close(db);

}


int * bd::get(const char * table){

    string SQL;
    SQL.append("SELECT * FROM  ");
    SQL.append(table);
    ix =0;
    Dm = new int[400];
    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),CB,0,&err);

    if(ch != SQLITE_OK) qDebug(err);
    sqlite3_close(db);

    return Dm;
}

int bd::CB(void * mu,int n,char ** val,char ** name){

    for(int i = 0;i<n;i++){

        Dm[ix] = std::stoi(val[i]);
        ix++;

    }
    return 0;
}

int bd::check(const char * table){


    string SQL;
    SQL.append("SELECT count(*) FROM  ");
    SQL.append(table);
    ix = 0;
    Dm = new int[10];
    sqlite3_open(FileName,&db);
    char * err;
    int ch = sqlite3_exec(db,SQL.c_str(),CB,0,&err);

    if(ch != SQLITE_OK) Dm[0] = 0;
    sqlite3_close(db);

    return Dm[0];

}
