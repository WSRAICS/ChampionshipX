#ifndef CAR_H
#define CAR_H
#include "mapx.h"
#include "bd.h"

#include <QLabel>
class car
{
public:
    int * trx;
    bd *BD;
    int end;
    int start;
    int x,y;
    QLabel * Lab;
    QPixmap IM1,IM2,IM3;
    mapx * map;
    int carID;
    int svID;
    int type;
    int ug;
    int ** Mar;
    int lMar;
    int nMar;
    long long int * tik;
    void del();
    car(QLabel *Labx,mapx * m,long long int * t);
    void  rotate(QPixmap *im1);
    QPixmap * rotate2(QPixmap *im1,int ug);
    void draw();
    void W();
    int mod(int x);
    QPixmap * add_im(QPixmap *im1,QPixmap *im2);
};

#endif // CAR_H
