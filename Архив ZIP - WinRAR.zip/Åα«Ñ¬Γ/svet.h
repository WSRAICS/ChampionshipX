#ifndef SVET_H
#define SVET_H


class svet
{
public:
    int x,y;
    int t;
    svet(int xx,int yy);
};

#endif // SVET_H
