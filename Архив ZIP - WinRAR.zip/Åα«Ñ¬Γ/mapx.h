#ifndef MAPX_H
#define MAPX_H
#include <QPushButton>
#include <QPixmap>
#include "svet.h"

class mapx
{
public:
    mapx();
    int carsZ;
    int nZ;
    int * Dmap;
    int * Omap;
    int * Cmap;
    int * Smap;
    int * Stmap;
    svet ** sm;
    int sn;
    QPushButton ** Bmap;

};

#endif // MAPX_H
