#ifndef EN_H
#define EN_H
#include <QLabel>
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include "car.h"
#include "mapx.h"

class en: public QMainWindow
{
    Q_OBJECT
public:
    int trx;
    int allCar;
    int nn;
    int nc;
    int ***MarS;
    long long int tik;
    int tikrat;
    QLabel ** Lab;
    car ** Car;
    mapx * map;
    en(QLabel ** L,mapx * m);
    car * getCar();
    void  setCar(int n);
    void neX();

public slots:
    void go();
};

#endif // EN_H
