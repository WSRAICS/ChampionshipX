#include "en.h"
#include <QDebug>
#include "mapx.h"
en::en(QLabel ** L,mapx * m)
{
    allCar = 0;
    map = m;
    MarS = new int **[50];
    int  m1[10][2] = {{2,1},{2,3},{12,3},{12,10},{20,10},{0,0},{0,0},{0,0},{0,0},{5,1}};

    int **mx = new int*[10];
    for(int i = 0;i<100;i++){
        mx[i] = new int [2];
    }
    for(int i = 0;i<10;i++){
        for(int k = 0;k<2;k++){
        mx[i][k] = m1[i][k];
        }
    }
    MarS[0] = mx;
    int  m2[10][2] = {{20,18},{17,18},{17,9},{13,9},{13,1},{0,0},{0,0},{0,0},{1,0},{5,1}};

    mx = new int*[100];
    for(int i = 0;i<100;i++){
        mx[i] = new int [2];
    }
    for(int i = 0;i<10;i++){
        for(int k = 0;k<2;k++){
        mx[i][k] = m2[i][k];
        }
    }
     MarS[1] = mx;

     int  m3[10][2] = {{12,1},{12,2},{2,2},{2,10},{5,10},{5,14},{1,14},{0,0},{2,0},{7,1}};

     mx = new int*[100];
     for(int i = 0;i<100;i++){
         mx[i] = new int [2];
     }
     for(int i = 0;i<10;i++){
         for(int k = 0;k<2;k++){
         mx[i][k] = m3[i][k];
         }
     }
      MarS[2] = mx;

      int  m4[10][2] = {{1,3},{2,3},{2,10},{20,10},{5,12},{5,16},{1,16},{0,0},{3,0},{4,1}};

      mx = new int*[100];
      for(int i = 0;i<100;i++){
          mx[i] = new int [2];
      }
      for(int i = 0;i<10;i++){
          for(int k = 0;k<2;k++){
          mx[i][k] = m4[i][k];
          }
      }
       MarS[3] = mx;

       int  m5[10][2] = {{1,10},{20,10},{2,12},{20,12},{5,12},{5,16},{1,16},{0,0},{4,0},{2,3}};

       mx = new int*[100];
       for(int i = 0;i<100;i++){
           mx[i] = new int [2];
       }
       for(int i = 0;i<10;i++){
           for(int k = 0;k<2;k++){
           mx[i][k] = m5[i][k];
           }
       }
        MarS[4] = mx;

        int  m6[10][2] = {{6,20},{6,14},{1,14},{20,12},{5,12},{5,16},{1,16},{0,0},{5,0},{3,3}};

        mx = new int*[100];
        for(int i = 0;i<100;i++){
            mx[i] = new int [2];
        }
        for(int i = 0;i<10;i++){
            for(int k = 0;k<2;k++){
            mx[i][k] = m6[i][k];
            }
        }
         MarS[5] = mx;

         int  m7[10][2] = {{20,13},{17,13},{17,9},{3,9},{3,1},{5,16},{1,16},{0,0},{6,0},{5,2}};

         mx = new int*[100];
         for(int i = 0;i<100;i++){
             mx[i] = new int [2];
         }
         for(int i = 0;i<10;i++){
             for(int k = 0;k<2;k++){
             mx[i][k] = m7[i][k];
             }
         }
          MarS[6] = mx;

          int  m8[10][2] = {{1,19},{3,19},{3,15},{9,15},{9,19},{20,19},{1,16},{0,0},{7,0},{6,2}};

          mx = new int*[100];
          for(int i = 0;i<100;i++){
              mx[i] = new int [2];
          }
          for(int i = 0;i<10;i++){
              for(int k = 0;k<2;k++){
              mx[i][k] = m8[i][k];
              }
          }
           MarS[7] = mx;

           int  m9[10][2] = {{20,4},{16,4},{16,9},{3,9},{3,6},{20,19},{1,16},{0,0},{8,0},{5,3}};

           mx = new int*[100];
           for(int i = 0;i<100;i++){
               mx[i] = new int [2];
           }
           for(int i = 0;i<10;i++){
               for(int k = 0;k<2;k++){
               mx[i][k] = m9[i][k];
               }
           }
            MarS[8] = mx;
            int  m10[10][2] = {{12,1},{12,2},{2,2},{2,10},{5,10},{5,14},{1,14},{0,0},{9,0},{7,1}};

            mx = new int*[100];
            for(int i = 0;i<100;i++){
                mx[i] = new int [2];
            }
            for(int i = 0;i<10;i++){
                for(int k = 0;k<2;k++){
                mx[i][k] = m10[i][k];
                }
            }
             MarS[9] = mx;

             int  m11[10][2] = {{17,20},{17,18},{10,18},{10,14},{6,14},{6,9},{1,9},{0,0},{10,0},{7,1}};

             mx = new int*[100];
             for(int i = 0;i<100;i++){
                 mx[i] = new int [2];
             }
             for(int i = 0;i<10;i++){
                 for(int k = 0;k<2;k++){
                 mx[i][k] = m11[i][k];
                 }
             }
              MarS[10] = mx;


    nc = 0;

    tik = 1;
    tikrat = 64;
    nn = 0;
    Lab = L;
    Car = new car*[400];
    trx =0;
    for(int i = 0;i<400;i++){

        Car[i] = new car(Lab[i],map,&tik);
        Car[i]->trx = &trx;

    }


}

void en::go(){

    //qDebug(std::to_string(tik).c_str());
    tik++;
    if(trx ==1  && tik%50==0){
        qDebug("xx");
        neX();

    }
    for(int i = 0;i<nn;i++){

        Car[i]->W();
        if(! Car[i]->end){
            Car[i]->draw();
        }else{
            setCar(i);
        }

    }


}

car * en::getCar(){
    nc++;
    allCar++;
    return Car[nc-1];

}
void  en::setCar(int n){
    car * c = Car[nc-1];
    Car[nc-1] = Car[n];
    Car[nc-1]->del();
    Car[n]= c;
    nc--;
    nn--;
}


void en::neX(){

    car * Car ;
    for(int i = 0;i<6;i++){
         Car = getCar();
         Car->Mar = MarS[i];
        Car->lMar = MarS[i][9][0];
         Car->type = MarS[i][9][1];
         Car->end = 0;
         Car->x = MarS[i][0][0]*50;
        Car->y = MarS[i][0][1]*50;
        Car->carID =allCar;

    }
     nn+=6;


}


