#include "mapx.h"
#include <QPushButton>
mapx::mapx()
{

     Dmap = new int[400];
     Omap = new int[400];
     Cmap = new int[400];
     Bmap = new QPushButton*[400];
    for(int i =0;i<400;i++){

        Dmap[i] = 6;
        Omap[i] = 0;
        Cmap[i] = 0;
    }
    sm = new svet*[400];
    sn = 0;
    carsZ=0;
    nZ=0;
}
