#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "mapx.h"
#include <QMainWindow>
#include <QPixmap>
#include <QTimer>
#include "en.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QTimer * ti1;
    en *EN;
    float xt;
    mapx * Map;
    QPixmap LD,RD,UD,DD,PD,WD,DZ,GZ,PZ,SVg,SVy,SVr,ZH,ZV,PE;
    int use_but;
    QPixmap *add_im(QPixmap *im1,QPixmap *im2);
    void  rotate(QPixmap *im1);
    QPixmap * get_im(int x);
    void draw_map();
    int * cr_svMap();
    int * cr_svTMap();
    int Xtik;
    int tipeSV;
    QPixmap * get_im2(int x,int xx,int yy);

    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:


    void on_LD_clicked();

    void on_RD_clicked();

    void on_UD_clicked();

    void on_DD_clicked();

    void on_PD_clicked();

    void on_WD_clicked();

    void on_DZ_clicked();

    void on_GZ_clicked();

    void on_PZ_clicked();

    void on_ZH_clicked();

    void on_ZV_clicked();

    void on_PE_clicked();

    void on_SV_clicked();


    void on_zz_clicked();

    void on_pushButton_clicked();

    void on_start_clicked();

    void on_stop_clicked();

public slots:
    void tEvent();
    void ch_map();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
