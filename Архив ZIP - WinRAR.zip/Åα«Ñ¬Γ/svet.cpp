#include "svet.h"

svet::svet(int xx,int yy)
{
    x = xx;
    y = yy;
    t = 1;
}
