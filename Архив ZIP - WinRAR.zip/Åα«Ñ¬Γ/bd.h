#ifndef BD_H
#define BD_H
#include "sqlite3.h"
#include "iostream"

static int * Dm;
static int ix;

using namespace std;
class bd
{
public:
    sqlite3 *db;
    const char * FileName;
    bd();
    void criate(char * table,int n,char ** val,char ** tipe);
    void criate2(string SQL);
    void cr_tmap(const char * t);
    void set_Car(int * map);
    void set_Lite(float * map);
    void set(const char * table,int n1,int n2, int * map);
    void drop(const char * table);
    int * get(const char * table);
    static int CB(void * mu,int n,char ** val,char ** name);
    int check(const char * table);
    void criateC();
    void criateL();
    void criateLR();
    void set_LR(int * map);

};

#endif // BD_H
