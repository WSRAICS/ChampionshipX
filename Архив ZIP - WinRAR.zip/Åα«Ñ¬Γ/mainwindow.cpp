#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include "mapx.h"
#include <QPixmap>
#include "bd.h"
#include <QPainter>
#include "en.h"
#include <QTimer>
#include "car.h"
#include <QLabel>
#include <QImage>
#include "cmath"

void MainWindow::tEvent(){
    Xtik++;
    if(Xtik==20*5){

        if(tipeSV == 1){
            xt =5;
            for(int i = 0;i<Map->sn;i++){

                if(Map->Stmap[Map->sm[i]->x*20+Map->sm[i]->y] == 1){
                    Map->Stmap[Map->sm[i]->x*20+Map->sm[i]->y] = 0;

                }else{
                    Map->Stmap[Map->sm[i]->x*20+Map->sm[i]->y] = 1;
                }

            }
            draw_map();
        }
         if(tipeSV == 2){
             int i = rand()%Map->sn;
             xt = rand()%500/100;
             if(Map->Stmap[Map->sm[i]->x*20+Map->sm[i]->y] == 1){
                 Map->Stmap[Map->sm[i]->x*20+Map->sm[i]->y] = 0;

             }else{
                 Map->Stmap[Map->sm[i]->x*20+Map->sm[i]->y] = 1;
             }
         }



        Xtik=0;
    }
    if(EN->trx!=0) ui->VI->setText(   std::to_string(EN->tik/20).c_str());
    if(EN->trx!=0) ui->NI->setText(   std::to_string(Map->nZ).c_str());
    EN->go();
}

QPixmap * MainWindow::add_im(QPixmap *im1,QPixmap *im2){
    QPixmap * ret = new QPixmap(im1->size());
    QPainter p(ret);
    p.drawPixmap(0,0,*im1);
    p.drawPixmap(0,0,*im2);

    return ret;
}

void  MainWindow::rotate(QPixmap *im1){
    QSize size = im1->size();
    int x = im1->width();
    int y = im1->height();

    QPixmap r(size*2);
    QPainter p(&r);
    p.translate(r.size().width()/2,r.size().height()/2);
    p.rotate(90);
    p.translate(-r.size().width()/2,-r.size().height()/2);

    p.drawPixmap(x,y,*im1);
    p.end();

    *im1 = r.copy(0,2*y-x,y,x);
}

QPixmap * MainWindow::get_im(int x){  //  DZ,GZ,PZ,SVg,SVy,SVr,ZH,ZV,PE;

    if(x ==1) return &LD;
    if(x ==2) return &RD;
    if(x ==3) return &UD;
    if(x ==4) return &DD;
    if(x ==5) return &PD;
    if(x ==6) return &WD;
    if(x ==7) return &DZ;
    if(x ==8) return &GZ;
    if(x ==9) return &PZ;
    if(x ==10) return &ZH;
    if(x ==11) return &ZV;
    if(x ==12) return &PE;
    if(x ==13) return &SVg;
    return &WD;

}
QPixmap * MainWindow::get_im2(int x,int xx,int yy){  //  DZ,GZ,PZ,SVg,SVy,SVr,ZH,ZV,PE;

    if(x ==1) return &LD;
    if(x ==2) return &RD;
    if(x ==3) return &UD;
    if(x ==4) return &DD;
    if(x ==5) return &PD;
    if(x ==6) return &WD;
    if(x ==7) return &DZ;
    if(x ==8) return &GZ;
    if(x ==9) return &PZ;
    if(x ==10) return &ZH;
    if(x ==11) return &ZV;
    if(x ==12) return &PE;
    if(x ==13) {

        if(Map->Stmap[xx*20+yy]==1)return &SVg;
        if(Map->Stmap[xx*20+yy]==0)return &SVr;
        }


    return &WD;

}
void MainWindow::draw_map(){

    for(int x = 0;x<20;x++){

        for(int y = 0;y<20;y++){

               if(Map->Dmap[x*20+y]!=6){
                   if(Map->Omap[x*20+y]!=0){

                        Map->Bmap[x*20+y]->setIcon(add_im(get_im( Map->Dmap[x*20+y]),get_im2( Map->Omap[x*20+y],x,y))->scaled(50,50));
                        Map->Bmap[x*20+y]->setIconSize(QSize(50,50));
                   }else{
                        Map->Bmap[x*20+y]->setIcon(get_im( Map->Dmap[x*20+y])->scaled(50,50));
                        Map->Bmap[x*20+y]->setIconSize(QSize(50,50));
                   }
               }
               if(Map->Dmap[x*20+y]==6){
                   if(Map->Omap[x*20+y]!=0){

                        Map->Bmap[x*20+y]->setIcon(add_im(get_im( Map->Dmap[x*20+y]),get_im2( Map->Omap[x*20+y],x,y))->scaled(48,48));
                        Map->Bmap[x*20+y]->setIconSize(QSize(48,48));
                   }else{
                        Map->Bmap[x*20+y]->setIcon(get_im( Map->Dmap[x*20+y])->scaled(48,48));
                        Map->Bmap[x*20+y]->setIconSize(QSize(48,48));
                   }
               }
        }

    }

}
void MainWindow::ch_map(){

    QPushButton *bat = qobject_cast<QPushButton *>(sender());

    int id = std::stoi(bat->objectName().toStdString().c_str());
     if(use_but<7&&use_but>0)Map->Dmap[id] = use_but;
     if(use_but>6){
         //if(Map->Dmap[id] == 5 && (use_but==13)) Map->Omap[id] = use_but;
         if(Map->Dmap[id] >0 &&Map->Dmap[id] <5 && (use_but==13||use_but==10 ||use_but==11||use_but==7||use_but==8||use_but==9  )) Map->Omap[id] = use_but;
         if((Map->Omap[id+1] == 11 || Map->Omap[id-1] == 11 ) && (use_but==12)) Map->Omap[id] = use_but;
         if((Map->Omap[id-20] == 10 || Map->Omap[id+20] == 10)  && (use_but==12)) Map->Omap[id] = use_but;
     }
     if(use_but==0)Map->Omap[id] = use_but;
     if(use_but == 13) {Map->Smap = cr_svMap();Map->Stmap = cr_svTMap();}
     draw_map();
}
int * MainWindow::cr_svMap(){

    int * ret = new int[400];
    for(int i = 0;i<20;i++){

        for(int j = 0;j<20;j++){

            if(Map->Omap[i*20+j]==13){
                Map->sm[Map->sn] = new svet(i,j);
                Map->sn++;
                ret[i*20+j]=0;


            }else{
                ret[i*20+j]=-1;
            }

        }

    }
    return ret;
}
int * MainWindow::cr_svTMap(){

    int * ret = new int[400];
    for(int i = 0;i<20;i++){

        for(int j = 0;j<20;j++){

            if(Map->Omap[i*20+j]==13){

                ret[i*20+j]=1;


            }else{
                ret[i*20+j]=-1;
            }

        }

    }
    return ret;
}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
     ui->setupUi(this);
     use_but = 0;
    Map = new mapx();

    Xtik = 0;
    xt = 0;

    bd BD;

    tipeSV = 1;
    //qDebug(std::to_string(BD.check("tDmap")).c_str());
    if(BD.check("tDmap")==400){
        int * Dxx = BD.get("tDmap");
        for(int i = 0;i<400;i++){

                Map->Dmap[i] = Dxx[i];

        }
    }

    if(BD.check("tOmap")==400){
        int * Dxx = BD.get("tOmap");
        for(int i = 0;i<400;i++){

                Map->Omap[i] = Dxx[i];

        }
    }


    WD.load(":/new/prefix1/Resources/Rvertical.png");
    WD.fill(QColor(30,30,30));


    LD.load(":/new/prefix1/Resources/Rvertical.png");
    rotate(&LD);
    rotate(&LD);


    RD.load(":/new/prefix1/Resources/Rvertical.png");

    UD.load(":/new/prefix1/Resources/Rvertical.png");
    rotate(&UD);

    DD.load(":/new/prefix1/Resources/Rvertical.png");
    rotate(&DD);
    rotate(&DD);
    rotate(&DD);

    PD.load(":/new/prefix1/Resources/Rcrossroads.png");

    DZ.load(":/new/prefix1/Resources/Block.png");

    GZ.load(":/new/prefix1/Resources/HeavyBlock2.png");

    PZ.load(":/new/prefix1/Resources/VagonBlock.png");

    SVg.load(":/new/prefix1/Resources/TLgreen.png");


    SVr.load(":/new/prefix1/Resources/TLred.png");

    ZH.load(":/new/prefix1/Resources/Zhorizontal.png");
    ZV.load(":/new/prefix1/Resources/Zvertical.png");

    PE.load(":/new/prefix1/Resources/Pedestrain.png");


    ui->LD->setIcon(LD.scaled(50,50));
    ui->LD->setIconSize(QSize(50,50));
    ui->LD->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->LD->setMaximumSize(50,50);
    ui->LD->setMinimumSize(50,50);

    ui->RD->setIcon(RD.scaled(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->RD->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->RD->setMaximumSize(50,50);
    ui->RD->setMinimumSize(50,50);

    ui->UD->setIcon(UD.scaled(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->UD->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->UD->setMaximumSize(50,50);
    ui->UD->setMinimumSize(50,50);

    ui->DD->setIcon(DD.scaled(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->DD->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->DD->setMaximumSize(50,50);
    ui->DD->setMinimumSize(50,50);

    ui->PD->setIcon(PD.scaled(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->PD->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->PD->setMaximumSize(50,50);
    ui->PD->setMinimumSize(50,50);

    ui->WD->setIcon(WD.scaled(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->WD->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->WD->setMaximumSize(50,50);
    ui->WD->setMinimumSize(50,50);

    ui->DZ->setIcon(add_im(&WD,&DZ)->scaled(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->DZ->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->DZ->setMaximumSize(50,50);
    ui->DZ->setMinimumSize(50,50);

    ui->GZ->setIcon(add_im(&WD,&GZ)->scaled(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->GZ->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->GZ->setMaximumSize(50,50);
    ui->GZ->setMinimumSize(50,50);

    ui->PZ->setIcon(add_im(&WD,&PZ)->scaled(50,50));
    ui->PZ->setIconSize(QSize(50,50));
    ui->PZ->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->PZ->setMaximumSize(50,50);
    ui->PZ->setMinimumSize(50,50);

    ui->SV->setIcon(add_im(&WD,&SVg)->scaled(50,50));
    ui->SV->setIconSize(QSize(50,50));
    ui->SV->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->SV->setMaximumSize(50,50);
    ui->SV->setMinimumSize(50,50);

    ui->ZH->setIcon(add_im(&WD,&ZH)->scaled(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZH->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->ZH->setMaximumSize(50,50);
    ui->ZH->setMinimumSize(50,50);

    ui->ZV->setIcon(add_im(&WD,&ZV)->scaled(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->ZV->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->ZV->setMaximumSize(50,50);
    ui->ZV->setMinimumSize(50,50);

    ui->PE->setIcon(add_im(&WD,&PE)->scaled(50,50));
    ui->PE->setIconSize(QSize(50,50));
    ui->PE->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->PE->setMaximumSize(50,50);
    ui->PE->setMinimumSize(50,50);

    ui->zz->setIcon(WD.scaled(50,50));
    ui->zz->setIconSize(QSize(50,50));
    ui->zz->setStyleSheet("border: 2px solid rgb(200,0,0);");
    ui->zz->setMaximumSize(50,50);
    ui->zz->setMinimumSize(50,50);




    ui->gridLayout->setSpacing(0);

    for(int i = 0;i<20;i++){
        for(int j = 0;j<20;j++){
            //rotate(&RD);
            Map->Bmap[i*20+j] = new QPushButton;
            Map->Bmap[i*20+j]->setObjectName(std::to_string(i*20+j).c_str());
            Map->Bmap[i*20+j]->setMaximumSize(50,50);
            Map->Bmap[i*20+j]->setMinimumSize(50,50);
            Map->Bmap[i*20+j]->setIcon(WD.scaled(48,48));
            Map->Bmap[i*20+j]->setIconSize(QSize(48,48));
            Map->Bmap[i*20+j]->setStyleSheet("border: 2px solid rgb(0,0,0);");
            ui->gridLayout->addWidget(Map->Bmap[i*20+j],j,i);
            connect(Map->Bmap[i*20+j],SIGNAL(clicked()),this,SLOT(ch_map()));

        }
    }




QLabel ** L = new QLabel*[400];

for(int i =0;i<400;i++){

    L[i] = new QLabel(this);
    L[i]->setGeometry(-100,-100,50,50);
    L[i]->setMaximumSize(50,50);
    L[i]->setMinimumSize(50,50);
    L[i]->setStyleSheet("background-color: rgba(100,0,0,0);");

}
Map->Smap = cr_svMap();
Map->Stmap = cr_svTMap();
EN = new en(L,Map);


ti1 = new QTimer;

connect(ti1,SIGNAL(timeout()),this,SLOT(tEvent()) );
ti1->start(1000.f/20.f);
draw_map();
}

MainWindow::~MainWindow()
{

    bd BD;
    BD.drop("tDmap");
    BD.cr_tmap("tDmap");
    BD.set("tDmap",400,1,Map->Dmap);
    BD.drop("tOmap");
    BD.cr_tmap("tOmap");
    BD.set("tOmap",400,1,Map->Omap);
    delete ui;
}


void MainWindow::on_LD_clicked()
{

            ui->LD->setIconSize(QSize(48,48));
            ui->RD->setIconSize(QSize(50,50));
            ui->UD->setIconSize(QSize(50,50));
            ui->DD->setIconSize(QSize(50,50));
            ui->PD->setIconSize(QSize(50,50));
            ui->WD->setIconSize(QSize(50,50));
            ui->DZ->setIconSize(QSize(50,50));
            ui->GZ->setIconSize(QSize(50,50));
            ui->PZ->setIconSize(QSize(50,50));
 ui->zz->setIconSize(QSize(50,50));
            ui->SV->setIconSize(QSize(50,50));
            ui->ZH->setIconSize(QSize(50,50));
            ui->ZV->setIconSize(QSize(50,50));
            ui->PE->setIconSize(QSize(50,50));

            use_but = 1 ;

}


void MainWindow::on_RD_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(48,48));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));
 ui->zz->setIconSize(QSize(50,50));
    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     use_but = 2 ;
}


void MainWindow::on_UD_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(48,48));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

     ui->zz->setIconSize(QSize(50,50));
    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     use_but = 3 ;
}


void MainWindow::on_DD_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(48,48));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     use_but = 4 ;
}


void MainWindow::on_PD_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(48,48));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     use_but = 5 ;
}


void MainWindow::on_WD_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(48,48));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
     use_but = 6 ;
}


void MainWindow::on_DZ_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(48,48));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
         use_but = 7 ;
}


void MainWindow::on_GZ_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(48,48));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
         use_but = 8 ;
}


void MainWindow::on_PZ_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(48,48));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
         use_but = 9 ;
}


void MainWindow::on_ZH_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(48,48));
    ui->ZV->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
         use_but = 10 ;
}


void MainWindow::on_ZV_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(48,48));
    ui->PE->setIconSize(QSize(50,50));
     ui->zz->setIconSize(QSize(50,50));
         use_but = 11 ;
}


void MainWindow::on_PE_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(48,48));
     ui->zz->setIconSize(QSize(50,50));
         use_but = 12 ;
}


void MainWindow::on_SV_clicked()
{

    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(48,48));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
    ui->zz->setIconSize(QSize(50,50));
         use_but = 13 ;
}


void MainWindow::on_zz_clicked()
{
    ui->LD->setIconSize(QSize(50,50));
    ui->RD->setIconSize(QSize(50,50));
    ui->UD->setIconSize(QSize(50,50));
    ui->DD->setIconSize(QSize(50,50));
    ui->PD->setIconSize(QSize(50,50));
    ui->WD->setIconSize(QSize(50,50));
    ui->DZ->setIconSize(QSize(50,50));
    ui->GZ->setIconSize(QSize(50,50));
    ui->PZ->setIconSize(QSize(50,50));

    ui->SV->setIconSize(QSize(50,50));
    ui->ZH->setIconSize(QSize(50,50));
    ui->ZV->setIconSize(QSize(50,50));
    ui->PE->setIconSize(QSize(50,50));
    ui->zz->setIconSize(QSize(48,48));
     use_but = 0 ;
}




/*  nt * map_to_bd(int * map){
    int ix = 0;
    int * ret = new int [1200];
    for(int i = 0;i<20;i++){

        for(int j = 0;j<20;j++){

            ret[ix] = i;
            ix++;
             ret[ix] = j;
            ix++;
             ret[ix] = map[i*20+j];
            ix++;

        }

    }
    return ret;
}

int * bd_to_map(int * bd){
    int ix = 0;
    int x,y;
    int * ret = new int [400];
    for(int i = 0;i<20;i++){

        for(int j = 0;j<20;j++){

            x = bd[ix];
            ix++;
            y = bd[ix];
            ix++;
            ret[x*20+j] = bd[ix];
            ix++;

        }

    }
    return ret;

class svet{

int type;

QPushButton * but;
QPixmap imG, imY,imR;

svet(QPushButton * b;QPixmap *G,QPixmap *Y,QPixmap *R,int t )

    but = b;
    imG = G;
    imY= Y;
    imR = R;
    type = t;

}

void swap(){

    if(type == 1) type = 3;
    if(type == 3) type = 1;
    if(type != 1 && type != 3) type = 2;
}

}


class svets{
    svet mapSV[400];
    int N;





}
}



*/

void MainWindow::on_pushButton_clicked()
{
   bd BD;
   BD.drop("Traffic_light");
   BD.drop("Cars_stats");
   BD.criateC();
   BD.criateL();
   car * Car ;
   for(int i = 0;i<11;i++){
        Car = EN->getCar();
        Car->Mar = EN->MarS[i];
       Car->lMar = EN->MarS[i][9][0];
        Car->type = EN->MarS[i][9][1];
        Car->end = 0;
        Car->x = EN->MarS[i][0][0]*50;
       Car->y = EN->MarS[i][0][1]*50;
       Car->carID =EN->allCar;

   }
     EN->nn+=11;
     EN->trx=1;
}


void MainWindow::on_start_clicked()
{

    bd BD;
    BD.drop("Traffic_light");
    BD.drop("Cars_stats");
    BD.criateC();
    BD.criateL();
    car * Car ;
    for(int i = 0;i<11;i++){
         Car = EN->getCar();
         Car->Mar = EN->MarS[i];
        Car->lMar = EN->MarS[i][9][0];
         Car->type = EN->MarS[i][9][1];
         Car->end = 0;
         Car->x = EN->MarS[i][0][0]*50;
        Car->y = EN->MarS[i][0][1]*50;
        Car->carID =EN->allCar;

    }
      EN->nn+=11;
      EN->trx=2;
      Map->carsZ =0;
      BD.drop("Learning_Records");
      BD.criateLR();
}


void MainWindow::on_stop_clicked()
{
    EN->trx = 0;
     Map->nZ++;
}

